<?php
namespace humhub\modules\ambcalendarsearch;

use DateTime;
use humhub\modules\ambcalendarsearch\widgets\CustomCalendarFilterBar;
use humhub\modules\calendar\models\fullcalendar\FullCalendar;
use Yii;

class Events{

    public static function onAfterGlobalControllerAction($event){
        if($event->action->actionMethod == 'actionLoadAjax'){
            $output = [];
            $start = Yii::$app->request->getQueryParam('start');
            $end = Yii::$app->request->getQueryParam('end');
            $filters = Yii::$app->request->get('filters', []);

            // Extract full text filter term from filters array, skipping single digit numbers
            $ftfTerm = null;
            foreach ($filters as $filter) {
                // Skip single digit numbers
                if (is_numeric($filter) && strlen($filter) === 1) {
                    continue;
                }
                $ftfTerm = $filter;
            }

            if (!Yii::$app->user->isGuest) {
                $settings = $event->sender->getUserSettings();

                $selectors = Yii::$app->request->get('selectors', []);
                $types = Yii::$app->request->get('types', []);

                $settings->setSerialized('lastSelectors', $selectors);
                $settings->setSerialized('lastFilters', $filters);

                $filters['userRelated'] = $selectors;


                $entries = $event->sender->calendarService->getCalendarItems(new DateTime($start), new DateTime($end), $filters, null, null, true, $types);
            } else {
                $entries = $event->sender->calendarService->getCalendarItems(new DateTime($start), new DateTime($end));
            }
            foreach ($entries as $entry) {
                if($ftfTerm) {
                    $search = $entry->getTitle() . ' xxx ' . $entry->getDescription();
                    if (stripos(strtolower($search), strtolower($ftfTerm)) === false) {
                        continue; // Skip this entry if it doesn't match the ftf term
                    }
                }
                $output[] = FullCalendar::getFullCalendarArray($entry);
            }
            $event->handled = true;
            $event->result = $event->sender->asJson($output);
        }
    }
}