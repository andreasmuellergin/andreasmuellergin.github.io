<?php
namespace humhub\modules\ambcalendarsearch;

use humhub\modules\ambcalendarsearch\assets\CalendarSearchAsset;
use Yii;

/**
 * Description of Events
 *
 */
class Module extends \humhub\components\Module {
    public function init()
    {
        parent::init();

        if (Yii::$app instanceof \yii\web\Application) {
            CalendarSearchAsset::register(Yii::$app->view);
        }
    }
}
