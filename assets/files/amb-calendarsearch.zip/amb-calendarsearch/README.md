HumHub - Module **amb-calendarsearch**
===========================

#### **HumHub is an intuitive to use and modular designed open-source software**, used primarily as social network, knowledge database, intranet or information and communication platform.

**Module description**

This modules purpose is to ammend the humhub calendar control with a text search box which filters the displayed items by title and description.

**Installation**
- Copy the module folder into the /humhub/protected/modules folder of your humhub application.
- Activate the module 
