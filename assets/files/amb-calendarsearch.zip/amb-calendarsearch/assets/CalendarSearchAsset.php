<?php

namespace humhub\modules\ambcalendarsearch\assets;

use yii\web\AssetBundle;

class CalendarSearchAsset extends AssetBundle
{
    public $sourcePath = '@ambcalendarsearch/resources';
    public $js = ['js/humhub.ambcalendarsearch.js'];
    public $depends = ['humhub\modules\calendar\assets\CalendarAsset'];
}