<?php
namespace humhub\modules\ambcalendarsearch;

use humhub\components\Controller;
use humhub\components\Widget;
use humhub\modules\calendar\controllers\GlobalController;
use humhub\modules\calendar\widgets\CalendarFilterBar;
use humhub\modules\calendar\widgets\FullCalendar;

return [
    'id' => 'ambcalendarsearch',
    'class' => 'humhub\modules\ambcalendarsearch\Module',
    'namespace' => 'humhub\modules\ambcalendarsearch',
    'events' => [
       [
            'class' => GlobalController::class, 
            'event' => Controller::EVENT_AFTER_ACTION, 
            'callback' => ['humhub\modules\ambcalendarsearch\Events', 'onAfterGlobalControllerAction']
        ],
    ],
];