humhub.module('ambcalendarsearch', function (module, require, $) {
    var widget = require('ui.widget');
    module.initOnPjaxLoad = true;

    module.init = function (isPjax) {

        // Use the HumHub event that fires after the calendar is ready
        $(document).on('humhub:modules:calendar:afterInit', function () {
            appendSearchInput();
        });
        appendSearchInput();
    };

    var appendSearchInput = function () {
        // Target the specific selector you found
        var $calendarEl = $('[data-ui-widget="calendar.Calendar"]');
        var $controls = $('.calendar-filters');
        if ($('#calendar-search-input').length || !$controls.length) {
            return;
        }

        // We add a text input with .filtercheckbox and checked in order to trick the calendar into accepting it as a filter 
        var $searchHtml = $('<div class="form-group" style="display:inline-block; margin-left:10px;">' +
            '<input type="text" id="calendar-search-input" class="form-control filterCheckbox" checked placeholder="Suchen ..." style="width:150px; height:32px;">' +
            '</div>');

        $controls.append($searchHtml);

        var typingTimer;
        $(document).on('keyup', '#calendar-search-input', function () {
            clearTimeout(typingTimer);

            typingTimer = setTimeout(function() {
                // Try to get the instance using the standard HumHub method
                var calendarInstance = $calendarEl.data('humhub-component');
                if (calendarInstance) {

                    // In the newer calendar, we trigger a fetch
                    if (typeof calendarInstance.fetch === 'function') {
                        // calendarInstance.fetch();
                        calendarInstance.updateCalendarFilters(true);
                    } 
                } else {
                    console.error("Calendar Search: Still could not find widget instance.");
                }
            }, 500);
        });
    };
});